import './App.css'
import ListFlights from './components/list-flights'
import AddFlight from './components/add-flight'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import FindCode from './components/find-code'
import FindCarrier from './components/find-carrier'
import FindRoute from './components/find-route'
import FindPrice from './components/find-price'


export default function App() {
  return (
    <div>
      <BrowserRouter>
    <nav className="navbar navbar-expand-sm premium-navbar sticky-top">
      <div className="container-fluid">
        <Link to="/" className="navbar-brand fw-bold">Flight-App</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link to="/add" className="nav-link">Add</Link>
            </li>
            <li className="nav-item">
              <Link to="/list" className="nav-link">List</Link>
            </li>
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" id="navbardrop" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Search By
              </a>
              <ul className="dropdown-menu">
                <li><Link to="/code" className="dropdown-item">Code</Link></li>
                <li><Link to="/carrier" className="dropdown-item">Carrier</Link></li>
                <li><Link to="/route" className="dropdown-item">Route</Link></li>
                <li><Link to="/price" className="dropdown-item">Price</Link></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <div className="main-content">
      <Routes>
        <Route path="/" element={<ListFlights />} />
        <Route path="/list" element={<ListFlights />} />
        <Route path="/add" element={<AddFlight />} />
        <Route path="/code" element={<FindCode />} />
        <Route path="/carrier" element={<FindCarrier />} />
        <Route path="/route" element={<FindRoute />} />
        <Route path="/price" element={<FindPrice />} />
        <Route path="*" element={<div className="alert alert-danger mt-4">Page Not Found</div>} />
      </Routes>
    </div>
    </BrowserRouter>
    </div>
  )
}
