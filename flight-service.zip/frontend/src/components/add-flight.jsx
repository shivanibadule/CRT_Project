import React, { Component } from 'react';
import FlightRestService from '../services/flight-rest-service';

export default class AddFlight extends Component {
    constructor(props) {
        super(props);
        this.service = new FlightRestService();
        this.state = {
            code: '',
            carrier: '',
            source: '',
            destination: '',
            cost: '',
            message: ''
        };
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row justify-content-center">
                    <div className="col-md-6">
                        <div className="card shadow">
                            <div className="card-header bg-primary text-white">
                                <h3 className="mb-0">Add New Flight</h3>
                            </div>
                            <div className="card-body">
                                {this.state.message && (
                                    <div className="alert alert-success">{this.state.message}</div>
                                )}
                                <form onSubmit={(e) => this.saveFlight(e)}>
                                    <div className="mb-3">
                                        <label className="form-label fw-bold">Flight Code:</label>
                                        <input type="number" name="code" className="form-control" value={this.state.code} onChange={(e) => this.handleChange(e)} required />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label fw-bold">Carrier:</label>
                                        <input type="text" name="carrier" className="form-control" value={this.state.carrier} onChange={(e) => this.handleChange(e)} required />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label fw-bold">Source:</label>
                                        <input type="text" name="source" className="form-control" value={this.state.source} onChange={(e) => this.handleChange(e)} required />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label fw-bold">Destination:</label>
                                        <input type="text" name="destination" className="form-control" value={this.state.destination} onChange={(e) => this.handleChange(e)} required />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label fw-bold">Cost:</label>
                                        <input type="number" step="0.01" name="cost" className="form-control" value={this.state.cost} onChange={(e) => this.handleChange(e)} required />
                                    </div>
                                    <div className="d-grid">
                                        <button type="submit" className="btn btn-primary btn-lg">Add Flight</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    handleChange(event) {
        let name = event.target.name;
        let value = event.target.value;
        this.setState({ [name]: value });
    }

    saveFlight(event) {
        event.preventDefault();
        let flight = {
            code: this.state.code,
            carrier: this.state.carrier,
            source: this.state.source,
            destination: this.state.destination,
            cost: this.state.cost
        };

        this.service.saveFlight(flight).then(response => {
            if (response && response.code) {
                this.setState({ message: 'Flight added successfully with Code: ' + response.code });
                this.resetForm();
            }
        });
    }

    resetForm() {
        this.setState({
            code: '',
            carrier: '',
            source: '',
            destination: '',
            cost: ''
        });
        
        setTimeout(() => {
            this.setState({ message: '' });
        }, 3000);
    }
}
