import React, { Component } from 'react';
import FlightRestService from '../services/flight-rest-service';
import ShowFlight from './show-flight';

export default class FindCarrier extends Component {
    constructor(props) {
        super(props);
        this.service = new FlightRestService();
        this.state = {
            carrier: '',
            flights: [],
            error: ''
        };
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row justify-content-center mb-4">
                    <div className="col-md-6">
                        <div className="card shadow-sm">
                            <div className="card-body">
                                <h4 className="card-title">Search Flights by Carrier</h4>
                                <div className="input-group mt-3">
                                    <input type="text" className="form-control" placeholder="Enter Carrier Name (e.g., Indigo)" 
                                        value={this.state.carrier} onChange={(e) => this.setState({ carrier: e.target.value })} />
                                    <button className="btn btn-primary" onClick={() => this.searchFlights()}>Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {this.state.error && <div className="alert alert-danger text-center">{this.state.error}</div>}

                {this.state.flights && this.state.flights.length > 0 && (
                    <div className="table-responsive">
                        <table className="table table-hover align-middle shadow-sm">
                            <thead className="table-dark">
                                <tr>
                                    <th className="px-4 py-3">Code</th>
                                    <th className="py-3">Carrier</th>
                                    <th className="py-3">Source</th>
                                    <th className="py-3">Destination</th>
                                    <th className="py-3">Cost</th>
                                    <th className="py-3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.state.flights.map((flight, index) => (
                                    <tr key={index}>
                                        <ShowFlight flight={flight} onDelete={this.doDelete} />
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        );
    }

    searchFlights() {
        this.setState({ flights: [], error: '' });
        this.service.getFlightByCarrier(this.state.carrier).then(data => {
            if (data && data.length > 0) {
                this.setState({ flights: data });
            } else {
                this.setState({ error: 'No flights found for carrier: ' + this.state.carrier });
            }
        });
    }

    doDelete = (code) => {
        this.service.deleteFlight(code).then(response => {
            this.searchFlights();
        });
    }
}
