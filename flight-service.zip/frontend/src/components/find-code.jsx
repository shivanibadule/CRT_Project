import React, { Component } from 'react';
import FlightRestService from '../services/flight-rest-service';
import ShowFlight from './show-flight';

export default class FindCode extends Component {
    constructor(props) {
        super(props);
        this.service = new FlightRestService();
        this.state = {
            code: '',
            flight: null,
            error: ''
        };
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row justify-content-center mb-4">
                    <div className="col-md-6">
                        <div className="card shadow-sm">
                            <div className="card-body">
                                <h4 className="card-title">Search Flight by Code</h4>
                                <div className="input-group mt-3">
                                    <input type="number" className="form-control" placeholder="Enter Flight Code" 
                                        value={this.state.code} onChange={(e) => this.setState({ code: e.target.value })} />
                                    <button className="btn btn-primary" onClick={() => this.searchFlight()}>Search</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {this.state.error && <div className="alert alert-danger text-center">{this.state.error}</div>}

                {this.state.flight && (
                    <div className="table-responsive">
                        <table className="table table-hover align-middle shadow-sm">
                            <thead className="table-dark">
                                <tr>
                                    <th className="px-4 py-3">Code</th>
                                    <th className="py-3">Carrier</th>
                                    <th className="py-3">Source</th>
                                    <th className="py-3">Destination</th>
                                    <th className="py-3">Cost</th>
                                    <th className="py-3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <ShowFlight flight={this.state.flight} onDelete={this.doDelete} />
                                </tr>
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        );
    }

    searchFlight() {
        this.setState({ flight: null, error: '' });
        this.service.getFlightByCode(this.state.code).then(data => {
            if (data && data.code) {
                this.setState({ flight: data });
            } else {
                this.setState({ error: 'Flight not found with code: ' + this.state.code });
            }
        });
    }

    doDelete = (code) => {
        this.service.deleteFlight(code).then(response => {
            this.setState({ flight: null, error: 'Flight deleted successfully' });
            setTimeout(() => {
                this.setState({ error: '' });
            }, 3000);
        });
    }
}
