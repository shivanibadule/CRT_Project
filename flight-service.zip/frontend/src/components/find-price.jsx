import React, { Component } from 'react';
import FlightRestService from '../services/flight-rest-service';
import ShowFlight from './show-flight';

export default class FindPrice extends Component {
    constructor(props) {
        super(props);
        this.service = new FlightRestService();
        this.state = {
            min: '',
            max: '',
            flights: [],
            error: ''
        };
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row justify-content-center mb-4">
                    <div className="col-md-6">
                        <div className="card shadow-sm">
                            <div className="card-body">
                                <h4 className="card-title">Search Flights by Price Range</h4>
                                <div className="row mt-3">
                                    <div className="col-5">
                                        <input type="number" step="0.01" className="form-control" placeholder="Min Price" 
                                            value={this.state.min} onChange={(e) => this.setState({ min: e.target.value })} />
                                    </div>
                                    <div className="col-5">
                                        <input type="number" step="0.01" className="form-control" placeholder="Max Price" 
                                            value={this.state.max} onChange={(e) => this.setState({ max: e.target.value })} />
                                    </div>
                                    <div className="col-2">
                                        <button className="btn btn-primary w-100" onClick={() => this.searchFlights()}>Search</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {this.state.error && <div className="alert alert-danger text-center">{this.state.error}</div>}

                {this.state.flights && this.state.flights.length > 0 && (
                    <div className="table-responsive">
                        <table className="table table-hover align-middle shadow-sm">
                            <thead className="table-dark">
                                <tr>
                                    <th className="px-4 py-3">Code</th>
                                    <th className="py-3">Carrier</th>
                                    <th className="py-3">Source</th>
                                    <th className="py-3">Destination</th>
                                    <th className="py-3">Cost</th>
                                    <th className="py-3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.state.flights.map((flight, index) => (
                                    <tr key={index}>
                                        <ShowFlight flight={flight} onDelete={this.doDelete} />
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        );
    }

    searchFlights() {
        this.setState({ flights: [], error: '' });
        this.service.getFlightByPriceRange(this.state.min, this.state.max).then(data => {
            if (data && data.length > 0) {
                this.setState({ flights: data });
            } else {
                this.setState({ error: `No flights found between ${this.state.min} and ${this.state.max}` });
            }
        });
    }

    doDelete = (code) => {
        this.service.deleteFlight(code).then(response => {
            this.searchFlights();
        });
    }
}
