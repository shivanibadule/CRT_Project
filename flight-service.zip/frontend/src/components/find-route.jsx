import React, { Component } from 'react';
import FlightRestService from '../services/flight-rest-service';
import ShowFlight from './show-flight';

export default class FindRoute extends Component {
    constructor(props) {
        super(props);
        this.service = new FlightRestService();
        this.state = {
            source: '',
            destination: '',
            flights: [],
            error: ''
        };
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row justify-content-center mb-4">
                    <div className="col-md-6">
                        <div className="card shadow-sm">
                            <div className="card-body">
                                <h4 className="card-title">Search Flights by Route</h4>
                                <div className="row mt-3">
                                    <div className="col-5">
                                        <input type="text" className="form-control" placeholder="Source" 
                                            value={this.state.source} onChange={(e) => this.setState({ source: e.target.value })} />
                                    </div>
                                    <div className="col-5">
                                        <input type="text" className="form-control" placeholder="Destination" 
                                            value={this.state.destination} onChange={(e) => this.setState({ destination: e.target.value })} />
                                    </div>
                                    <div className="col-2">
                                        <button className="btn btn-primary w-100" onClick={() => this.searchFlights()}>Search</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {this.state.error && <div className="alert alert-danger text-center">{this.state.error}</div>}

                {this.state.flights && this.state.flights.length > 0 && (
                    <div className="table-responsive">
                        <table className="table table-hover align-middle shadow-sm">
                            <thead className="table-dark">
                                <tr>
                                    <th className="px-4 py-3">Code</th>
                                    <th className="py-3">Carrier</th>
                                    <th className="py-3">Source</th>
                                    <th className="py-3">Destination</th>
                                    <th className="py-3">Cost</th>
                                    <th className="py-3">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {this.state.flights.map((flight, index) => (
                                    <tr key={index}>
                                        <ShowFlight flight={flight} onDelete={this.doDelete} />
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        );
    }

    searchFlights() {
        this.setState({ flights: [], error: '' });
        this.service.getFlightByRoute(this.state.source, this.state.destination).then(data => {
            if (data && data.length > 0) {
                this.setState({ flights: data });
            } else {
                this.setState({ error: `No flights found from ${this.state.source} to ${this.state.destination}` });
            }
        });
    }

    doDelete = (code) => {
        this.service.deleteFlight(code).then(response => {
            this.searchFlights();
        });
    }
}
