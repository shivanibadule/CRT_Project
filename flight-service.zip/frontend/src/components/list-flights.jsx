import React, { Component } from 'react';
import FlightRestService from '../services/flight-rest-service';
import ShowFlight from './show-flight';

export default class ListFlights extends Component {

    constructor(props) {
        super(props);
        this.service = new FlightRestService();
        this.state = {
            flights: null
        };
    }

    componentDidMount() {
        this.getFlights();
    }

    getFlights() {
        this.service.getAllFlights().then(data => {
            this.setState({ flights: data });
        });
    }

    render() {
        if (!this.state.flights || this.state.flights.length === 0)
            return <div>Loading or no flights found...</div>
        
        return (
            <div className="container mt-5">
                <h1 className="mb-4">List of Flights</h1>
                <div className="table-responsive">
                    <table className="table table-hover align-middle shadow-sm">
                        <thead className="table-dark">
                            <tr>
                                <th className="px-4 py-3">Code</th>
                                <th className="py-3">Carrier</th>
                                <th className="py-3">Source</th>
                                <th className="py-3">Destination</th>
                                <th className="py-3">Cost</th>
                                <th className="py-3">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.flights.map((flight, index) => (
                                <tr key={index}>
                                    <ShowFlight flight={flight} onDelete={this.doDelete} />
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }

    doDelete = (code) => {
        this.service.deleteFlight(code).then(response => {
            this.getFlights();
        });
    }

}
