import React, { Component } from 'react';

export default class ShowFlight extends Component {
    constructor(props) {
        super(props);
        this.state = {
            flight: props.flight
        };
    }

    render() {
        return (
            <> 
                <td className="px-4">{this.state.flight.code}</td>
                <td>{this.state.flight.carrier}</td>
                <td>{this.state.flight.source}</td>
                <td>{this.state.flight.destination}</td>
                <td>{this.state.flight.cost}</td>
                <td>
                    <button className="btn btn-outline-danger btn-sm rounded-pill px-3" onClick={() => this.onDelete()}>Delete</button>
                </td>
            </>
        );
    }

    onDelete() {
        if(window.confirm("Are you sure to delete flight code: " + this.state.flight.code + "?"))
            this.props.onDelete(this.state.flight.code);
    }
}
