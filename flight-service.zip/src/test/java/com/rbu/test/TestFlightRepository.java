package com.rbu.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;

import com.rbu.entity.Flight;
import com.rbu.repo.FlightRepository;

@Disabled
@DataJpaTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestFlightRepository {

    @Autowired
    private FlightRepository repo;

    @Test
    public void testFindByCode() {
        Optional<Flight> entity = repo.findById(101);
        assertTrue(entity.isPresent());
        assertEquals(entity.get().getCarrier(), "Indigo");
    }

    @Test
    @DisplayName("Test 1: Save Flight Test")
    @Order(1)
    public void testSave() {
        Flight flight = new Flight(103, "SpiceJet", "Nagpur", "Mumbai", 4200);
        Flight savedEntity = repo.save(flight);
        assertNotNull(savedEntity);
    }

    @Test
    @Order(2)
    public void testFindById() {
        Flight flight = repo.findById(103).get();
        assertNotNull(flight);
    }

    @Test
    @Order(3)
    public void testFindAll() {
        List<Flight> flights = repo.findAll();
        assertTrue(flights.size() > 0);
    }

    @Test
    @Order(4)
    public void testFindByCarrier() {
        List<Flight> flights = repo.findByCarrier("Indigo");
        assertTrue(flights.size() > 0);
    }

    @Test
    @Order(5)
    public void testFindByRoute() {
        List<Flight> flights = repo.findByRoute("Nagpur", "Pune");
        assertTrue(flights.size() > 0);
    }

    @Test
    @Order(6)
    public void testFindByPriceRange() {
        List<Flight> flights = repo.findByPriceRange(3000, 6000);
        assertTrue(flights.size() > 0);
    }

    @Test
    @Order(7)
    public void testDelete() {
        repo.deleteById(103);
        Optional<Flight> flight = repo.findById(103);
        assertTrue(flight.isEmpty());
    }
}