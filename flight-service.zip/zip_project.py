import os
import zipfile

def create_zip(source_dir, output_filename, exclude_dirs):
    # Ensure source_dir is absolute
    source_dir = os.path.abspath(source_dir)
    print(f"Zipping {source_dir} into {output_filename}")
    
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            # modify dirs in-place to avoid walking into excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, source_dir)
                zipf.write(file_path, arcname)

if __name__ == "__main__":
    excludes = {'node_modules', 'target', '.git', '.settings', '.mvn'}
    create_zip('.', 'flight-service.zip', excludes)
    print("Zip file created successfully.")
